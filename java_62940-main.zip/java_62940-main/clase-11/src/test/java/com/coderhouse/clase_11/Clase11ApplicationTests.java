package com.coderhouse.clase_11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
