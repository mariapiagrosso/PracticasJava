package com.coderhouse.clase_08;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase08ApplicationTests {

	@Test
	void contextLoads() {
	}

}
