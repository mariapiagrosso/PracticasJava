package com.coderhouse.clase_12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
