package com.coderhouse.clase_12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase12Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase12Application.class, args);
	}

}
