package com.coderhouse.clase_12.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AsignacionCategoriaCursoDTO {

    private Long cursoId;
    private Long categoriaId;
}
