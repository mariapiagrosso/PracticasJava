package com.coderhouse.finalEcommerce.dao;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AsignacionCatetoriaProductoDTO {

    private Long productoId;
    private Long categoriaId;
}
