package org.coderhouse;

public class Clase01 {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        //Declaración de variables
        byte variableA = 100;
        double variableConDecimales = 1599999.501d;
        char miPrimerChar = 'N';
        String miSegundoChar = "Mi primer String";
        boolean verdadero = false;
        long numeroLargo = 12312312312312312L;

    }
}