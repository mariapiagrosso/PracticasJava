package org.coderhouse.excepciones;

public class PerroException extends Exception {

    public PerroException(String mensaje) {
        super(mensaje);
    }

}
