package org.coderhouse.interfaces;

public interface CRUDInterface {

}
