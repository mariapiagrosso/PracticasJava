package org.coderhouse.interfaces;

public interface SerVivoInterface {

    String UBICACION = "Planeta Tierra";

    public void emitirSonido();
    public void moverse();
    public void comer();
    public boolean estaVivo();

}
