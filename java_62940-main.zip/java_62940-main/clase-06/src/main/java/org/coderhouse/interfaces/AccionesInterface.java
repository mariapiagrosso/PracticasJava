package org.coderhouse.interfaces;

public interface AccionesInterface {
    void dormir();
    void respirar();
    void jugar();
}
